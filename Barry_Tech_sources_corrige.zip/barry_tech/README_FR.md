# Barry Tech — version de départ

Application Flutter commune à Windows 10 et Android : transfert local dans les deux sens et lecture des vidéos reçues.

## Ce que contient cette version
- Un serveur HTTP local sur le port `8765` sur chaque appareil.
- Envoi de fichiers vers l'adresse IP de l'appareil destinataire.
- Réception dans le dossier `Documents/BarryTech/Received` de l'application.
- Barre de progression et liste des fichiers reçus.
- Lecture des vidéos reçues (MP4, MKV, AVI, MOV, WEBM, M4V, 3GP selon les codecs disponibles).

## Limite importante de cette première version
La découverte automatique des appareils, la reprise d'un transfert interrompu et le transfert en arrière-plan ne sont pas encore intégrés. Pour envoyer un fichier, saisissez l'adresse IP affichée sur l'appareil destinataire. Le téléphone peut isoler les appareils connectés à son partage de connexion : si les deux appareils ne communiquent pas, essayez un routeur Wi-Fi ou un câble USB avec partage de connexion USB. La vitesse dépend du matériel et du réseau ; aucun débit maximal n'est garanti.

Le transfert utilise HTTP sur le réseau local. Utilisez-le uniquement sur un réseau de confiance. Cette version ne chiffre pas les fichiers pendant le transfert.

## Pré-requis
- Flutter SDK stable installé.
- Android Studio (Android SDK) pour compiler l'APK.
- Visual Studio 2022 avec la charge de travail **Desktop development with C++** pour compiler Windows.
- Windows 10 pour la compilation Windows.

Vérifier l'environnement :
```bash
flutter doctor
```

## Générer les projets natifs
À la racine du projet :
```bash
flutter create --platforms=windows,android .
```
Cette commande crée les dossiers natifs manquants. Ensuite, vérifiez que `android/app/src/main/AndroidManifest.xml` contient bien les permissions et options de ce dépôt (remettez ce fichier si Flutter l'a remplacé).

## Compiler pour Android (.apk)
Connectez un téléphone Android pour les tests, ou activez les options développeur et le débogage USB.
```bash
flutter pub get
flutter build apk --release
```
APK généré :
`build/app/outputs/flutter-apk/app-release.apk`

Pour installer sur un téléphone connecté :
```bash
flutter install
```

## Compiler pour Windows (.exe)
Sur un PC Windows avec Visual Studio 2022 et C++ Desktop installés :
```powershell
flutter pub get
flutter build windows --release
```
Le programme se trouve dans :
`build\windows\x64\runner\Release\`
Lancez `barry_tech.exe`. Gardez les DLL et dossiers de ressources qui l'accompagnent : ne copiez pas uniquement le fichier EXE.

Au premier lancement, autorisez Barry Tech dans le pare-feu Windows pour les réseaux privés. Si nécessaire, ouvrez le port TCP entrant `8765` sur le profil Privé uniquement.

## Utilisation
1. Installez/lancez Barry Tech sur le PC et sur Android.
2. Connectez les deux appareils au même Wi-Fi ou au partage de connexion.
3. Sur l'appareil qui doit recevoir, repérez l'IP affichée dans le bandeau.
4. Sur l'appareil qui envoie, choisissez « Choisir et envoyer », sélectionnez le fichier et saisissez l'IP du destinataire (sans `:8765`).
5. Le fichier reçu apparaît dans la liste ; touchez-le pour lire une vidéo.

## Dépannage
- Si l'IP est `IP indisponible`, vérifiez que le Wi-Fi est connecté, puis relancez l'application.
- Si l'envoi échoue, vérifiez que les deux appareils sont sur le même réseau, que le port TCP 8765 est autorisé et que le partage de connexion n'isole pas les clients.
- Certains opérateurs/téléphones ne permettent pas aux appareils connectés au hotspot de communiquer entre eux.
- Si une vidéo ne se lit pas, essayez VLC ou un fichier MP4 H.264/AAC.

## Sécurité et prochaines améliorations
Cette version est un prototype fonctionnel de départ, pas encore un produit prêt à distribuer. Avant une utilisation sur des réseaux publics, il faudra ajouter un code d'appairage, du chiffrement TLS, des limites de taille et une meilleure gestion des erreurs. Les prochaines améliorations possibles : découverte automatique, reprise des transferts, sélection du dossier de destination, lecteur avec sous-titres et transfert en arrière-plan.


## Compilation à distance (sans installer Flutter sur votre PC)

Le projet inclut maintenant `.github/workflows/build.yml`, qui permet à GitHub Actions de compiler l'APK Android et l'application Windows sur des machines cloud GitHub.

1. Créez un compte GitHub si vous n'en avez pas : https://github.com/
2. Créez un dépôt vide, par exemple `barry-tech`.
3. Importez le contenu de cette archive dans le dépôt (pas l'archive ZIP elle-même).
4. Ouvrez l'onglet **Actions**, sélectionnez **Build Barry Tech**, puis cliquez sur **Run workflow**.
5. Lorsque l'exécution est terminée, ouvrez-la et téléchargez les deux artefacts : `Barry-Tech-Android-APK` et `Barry-Tech-Windows`.

Cette compilation distante n'a pas été exécutée ni validée depuis cet environnement. Elle nécessite un compte GitHub et une connexion Internet pour importer le code et lancer l'action. Les fichiers téléchargés sont des artefacts de test ; le ZIP Windows contient tous les fichiers d'exécution, pas seulement le `.exe`.
