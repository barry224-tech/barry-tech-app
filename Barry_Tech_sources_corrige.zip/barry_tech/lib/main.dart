import 'dart:async';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:video_player/video_player.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const BarryTechApp());
}

const int transferPort = 8765;
const Color navy = Color(0xFF123B70);
const Color blue = Color(0xFF2878D0);
const Color paleBlue = Color(0xFFEAF3FF);

class BarryTechApp extends StatelessWidget {
  const BarryTechApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Barry Tech',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: blue, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF6F9FE),
        appBarTheme: const AppBarTheme(backgroundColor: Colors.white, foregroundColor: navy),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 1,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  HttpServer? _server;
  String _status = 'Serveur arrêté';
  String _localIp = 'Recherche…';
  String _receivedFolder = '';
  String _targetIp = '';
  double _progress = 0;
  String _transferMessage = 'Aucun transfert en cours';
  bool _busy = false;
  List<FileSystemEntity> _received = [];

  @override
  void initState() {
    super.initState();
    _loadFolder();
    _refreshReceived();
    _startServer();
    _findLocalIp();
  }

  Future<Directory> _destinationFolder() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}${Platform.pathSeparator}BarryTech${Platform.pathSeparator}Received');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<void> _loadFolder() async {
    final dir = await _destinationFolder();
    if (mounted) setState(() => _receivedFolder = dir.path);
  }

  Future<void> _findLocalIp() async {
    try {
      final interfaces = await NetworkInterface.list(type: InternetAddressType.IPv4, includeLoopback: false);
      for (final interface in interfaces) {
        for (final address in interface.addresses) {
          if (!address.isLoopback && address.address.startsWith('192.168.') ||
              (!address.isLoopback && address.address.startsWith('10.'))) {
            if (mounted) setState(() => _localIp = address.address);
            return;
          }
        }
      }
      if (interfaces.isNotEmpty && interfaces.first.addresses.isNotEmpty) {
        if (mounted) setState(() => _localIp = interfaces.first.addresses.first.address);
      } else {
        if (mounted) setState(() => _localIp = 'IP indisponible');
      }
    } catch (_) {
      if (mounted) setState(() => _localIp = 'IP indisponible');
    }
  }

  Future<void> _startServer() async {
    try {
      _server = await HttpServer.bind(InternetAddress.anyIPv4, transferPort, shared: true);
      if (mounted) setState(() => _status = 'Prêt à recevoir');
      _server!.listen(_handleRequest, onError: (e) {
        if (mounted) setState(() => _status = 'Erreur serveur : $e');
      });
    } catch (e) {
      if (mounted) setState(() => _status = 'Impossible de démarrer : $e');
    }
  }

  Future<void> _handleRequest(HttpRequest request) async {
    if (request.method == 'GET' && request.uri.path == '/health') {
      request.response.headers.contentType = ContentType.text;
      request.response.write('Barry Tech ready');
      await request.response.close();
      return;
    }
    if (request.method == 'POST' && request.uri.path == '/upload') {
      final rawName = request.uri.queryParameters['name'] ?? 'fichier_recu';
      final safeName = _safeFileName(rawName);
      try {
        final folder = await _destinationFolder();
        final file = File('${folder.path}${Platform.pathSeparator}${DateTime.now().millisecondsSinceEpoch}_$safeName');
        final sink = file.openWrite();
        await request.cast<List<int>>().pipe(sink);
        request.response.statusCode = HttpStatus.ok;
        request.response.write('OK');
        await request.response.close();
        await _refreshReceived();
        if (mounted) setState(() => _transferMessage = 'Reçu : $safeName');
      } catch (e) {
        request.response.statusCode = HttpStatus.internalServerError;
        request.response.write('Erreur : $e');
        await request.response.close();
      }
      return;
    }
    request.response.statusCode = HttpStatus.notFound;
    await request.response.close();
  }

  String _safeFileName(String name) {
    final cleaned = name.replaceAll(RegExp(r'[\\/:*?"<>|]'), '_').trim();
    return cleaned.isEmpty ? 'fichier_recu' : cleaned;
  }

  Future<void> _refreshReceived() async {
    try {
      final dir = await _destinationFolder();
      final items = dir.listSync().whereType<File>().toList()
        ..sort((a, b) => b.statSync().modified.compareTo(a.statSync().modified));
      if (mounted) setState(() => _received = items);
    } catch (_) {}
  }

  Future<void> _chooseAndSend() async {
    final result = await FilePicker.platform.pickFiles(allowMultiple: true, withData: false);
    if (result == null || result.files.isEmpty) return;
    final controller = TextEditingController(text: _targetIp);
    final ip = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Adresse IP de l’autre appareil'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.url,
          decoration: const InputDecoration(hintText: 'Ex. 192.168.43.120', labelText: 'IP du destinataire'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Continuer')),
        ],
      ),
    );
    if (ip == null || ip.isEmpty) return;
    _targetIp = ip;
    for (final picked in result.files) {
      if (picked.path == null) continue;
      await _sendFile(File(picked.path!), ip);
      if (!mounted) return;
    }
  }

  Future<void> _sendFile(File file, String ip) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _progress = 0;
      _transferMessage = 'Envoi de ${file.uri.pathSegments.last}…';
    });
    try {
      final length = await file.length();
      final request = http.StreamedRequest('POST', Uri(
        scheme: 'http',
        host: ip,
        port: transferPort,
        path: '/upload',
        queryParameters: {'name': file.uri.pathSegments.last},
      ));
      request.headers['Content-Type'] = 'application/octet-stream';
      request.contentLength = length;
      var sent = 0;
      final stream = file.openRead().transform(
        StreamTransformer<List<int>, List<int>>.fromHandlers(handleData: (data, sink) {
          sent += data.length;
          sink.add(data);
          if (mounted) setState(() => _progress = length == 0 ? 1 : sent / length);
        }),
      );
      final responseFuture = request.send().timeout(const Duration(hours: 6));
      await request.sink.addStream(stream);
      await request.sink.close();
      final response = await responseFuture;
      if (response.statusCode != 200) throw HttpException('Réponse ${response.statusCode}');
      if (mounted) setState(() {
        _progress = 1;
        _transferMessage = 'Transfert terminé : ${file.uri.pathSegments.last}';
      });
    } catch (e) {
      if (mounted) setState(() => _transferMessage = 'Échec du transfert : $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _play(File file) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => VideoPage(file: file)));
  }

  Future<void> _delete(File file) async {
    await file.delete();
    await _refreshReceived();
  }

  @override
  void dispose() {
    _server?.close(force: true);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.swap_horiz_rounded, color: blue),
          SizedBox(width: 10),
          Text('Barry Tech', style: TextStyle(fontWeight: FontWeight.w800)),
        ]),
      ),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 900),
            child: ListView(
              padding: const EdgeInsets.all(18),
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [navy, blue]),
                    borderRadius: BorderRadius.circular(22),
                  ),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Votre espace de transfert', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text('IP de cet appareil : $_localIp:$transferPort', style: const TextStyle(color: Colors.white)),
                    const SizedBox(height: 5),
                    Text(_status, style: const TextStyle(color: Colors.white70)),
                    const SizedBox(height: 12),
                    const Text('Connectez les deux appareils au même Wi-Fi ou au partage de connexion.', style: TextStyle(color: Colors.white70)),
                  ]),
                ),
                const SizedBox(height: 16),
                Card(child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    const Text('Transférer des fichiers', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: navy)),
                    const SizedBox(height: 6),
                    const Text('Choisissez les fichiers, puis saisissez l’IP affichée sur l’appareil qui doit les recevoir.'),
                    const SizedBox(height: 14),
                    SizedBox(width: double.infinity, child: FilledButton.icon(
                      onPressed: _busy ? null : _chooseAndSend,
                      icon: const Icon(Icons.upload_rounded),
                      label: const Text('Choisir et envoyer'),
                    )),
                    const SizedBox(height: 12),
                    LinearProgressIndicator(value: _busy ? _progress : (_progress == 1 ? 1 : null), minHeight: 7),
                    const SizedBox(height: 8),
                    Text(_transferMessage, style: const TextStyle(fontSize: 13)),
                  ]),
                )),
                const SizedBox(height: 16),
                Card(child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      const Expanded(child: Text('Fichiers reçus', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: navy))),
                      IconButton(onPressed: _refreshReceived, icon: const Icon(Icons.refresh)),
                    ]),
                    Text(_receivedFolder, style: const TextStyle(fontSize: 11, color: Colors.black54)),
                    const SizedBox(height: 8),
                    if (_received.isEmpty)
                      const Padding(padding: EdgeInsets.symmetric(vertical: 22), child: Center(child: Text('Aucun fichier reçu pour le moment.')))
                    else
                      ..._received.map((entity) {
                        final file = entity as File;
                        final name = file.uri.pathSegments.last;
                        final video = RegExp(r'\.(mp4|mkv|avi|mov|webm|m4v|3gp)$', caseSensitive: false).hasMatch(name);
                        return ListTile(
                          contentPadding: EdgeInsets.zero,
                          leading: Icon(video ? Icons.movie_outlined : Icons.insert_drive_file_outlined, color: blue),
                          title: Text(name, maxLines: 1, overflow: TextOverflow.ellipsis),
                          subtitle: Text(_formatBytes(file.lengthSync())),
                          trailing: PopupMenuButton<String>(
                            onSelected: (value) {
                              if (value == 'play' && video) _play(file);
                              if (value == 'delete') _delete(file);
                            },
                            itemBuilder: (_) => [
                              if (video) const PopupMenuItem(value: 'play', child: Text('Lire la vidéo')),
                              const PopupMenuItem(value: 'delete', child: Text('Supprimer')),
                            ],
                          ),
                          onTap: video ? () => _play(file) : null,
                        );
                      }),
                  ]),
                )),
                const SizedBox(height: 10),
                const Text('Astuce : le transfert local ne consomme normalement pas votre forfait Internet. La vitesse dépend du Wi-Fi/hotspot et des appareils.', style: TextStyle(fontSize: 12, color: Colors.black54)),
              ],
            ),
          ),
        ),
      ),
    );
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes o';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} Ko';
    if (bytes < 1024 * 1024 * 1024) return '${(bytes / (1024 * 1024)).toStringAsFixed(1)} Mo';
    return '${(bytes / (1024 * 1024 * 1024)).toStringAsFixed(2)} Go';
  }
}

class VideoPage extends StatefulWidget {
  final File file;
  const VideoPage({super.key, required this.file});
  @override
  State<VideoPage> createState() => _VideoPageState();
}

class _VideoPageState extends State<VideoPage> {
  VideoPlayerController? _controller;
  String? _error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final controller = VideoPlayerController.file(widget.file);
      await controller.initialize();
      await controller.setLooping(false);
      if (!mounted) {
        await controller.dispose();
        return;
      }
      setState(() => _controller = controller);
    } catch (e) {
      if (mounted) setState(() => _error = 'Lecture impossible : $e');
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final c = _controller;
    return Scaffold(
      appBar: AppBar(title: Text(widget.file.uri.pathSegments.last, maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: Center(
        child: _error != null
            ? Text(_error!)
            : c == null
                ? const CircularProgressIndicator()
                : AspectRatio(
                    aspectRatio: c.value.aspectRatio,
                    child: Stack(alignment: Alignment.bottomCenter, children: [
                      VideoPlayer(c),
                      VideoProgressIndicator(c, allowScrubbing: true, colors: const VideoProgressColors(playedColor: blue)),
                      Align(
                        alignment: Alignment.center,
                        child: IconButton.filled(
                          iconSize: 42,
                          onPressed: () => setState(() => c.value.isPlaying ? c.pause() : c.play()),
                          icon: Icon(c.value.isPlaying ? Icons.pause : Icons.play_arrow),
                        ),
                      ),
                    ]),
                  ),
      ),
    );
  }
}
